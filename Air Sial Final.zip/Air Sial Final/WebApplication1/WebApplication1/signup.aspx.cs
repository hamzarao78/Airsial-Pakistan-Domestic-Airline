﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class signup : System.Web.UI.Page
    {
        Airsial01DataContext db = new Airsial01DataContext();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            signup s = new signup();
            s._FirstName = txtFirstName.Text;
            s._LastName = txtLastName.Text;
            s._ContactNumber = textContact.Text;
            s._YourEmail = txtYourEmail.Text;
            s.Gender = ddlGender.Text;
            s.Password = txtPassword.Text;
            s.ConfirmPassword = txtConfirmPassword.Text;

            db.signups.InsertOnSubmit(s);
            db.SubmitChanges();

        }
    }
}